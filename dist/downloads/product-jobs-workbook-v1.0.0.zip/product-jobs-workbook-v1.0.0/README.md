# 中国留学生产品岗位求职｜完整样例与可编辑模板

作者：AI酋长Andy｜版本 1.0.0｜2026-11-13

本包含 15 份模板及填写说明、12 个样例文件、完整案例章节、可本地运行的原型与所需图像。所有 OfferTrail 申请者、雇主和六条情境均为教学模拟；没有真实访谈、上线、增长或录用结果。

1. 先打开 [index.html](index.html)，或直接用浏览器打开 [原型](prototypes/offertrail.html)。无需账号、网络服务或真实申请资料。
2. 阅读 [样例入口](examples/README.md) 和 [贯穿案例](content/case/06-end-to-end-case.md)。
3. 复制 [模板](templates/README.md)，删除教学行，填写本人真实完成的工作。CSV 使用 UTF-8 编码。
4. 原型仅保存当前页面的模拟状态；核对完成不等于实际投递，也不验证工作许可。

Markdown 可在文本编辑器中阅读和修改。文件夹结构应整体保留，避免相对链接失效。

正式网站目标：https://aipmandy.github.io/chinese-international-student-product-jobs/。仅在远端部署与实际访问通过后才可视为已上线；本包不证明线上状态。

微信：AIPMAndy｜公众号：AI酋长Andy  
个人官网：https://metaver.vip/ ｜公司官网：https://www.a6no1.cn/

完整免费开放。咨询可用于岗位定位、作品集诊断和模拟面试，不承诺录用或涨薪。

代码 MIT；原创内容 CC BY 4.0，详见随包许可。PACKAGE-MANIFEST.json 记录文件哈希与包范围，不是用户研究或上线证明。
